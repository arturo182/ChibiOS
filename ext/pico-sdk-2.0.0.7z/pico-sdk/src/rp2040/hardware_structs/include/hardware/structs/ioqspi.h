/**
 * Copyright (c) 2024 Raspberry Pi Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Support old header for compatibility (and if included, support old variable name)
#include "hardware/structs/io_qspi.h"
#define ioqspi_hw io_qspi_hw