/**
 * \defgroup pico_clib_interface pico_clib_interface
 * \brief Provides the necessary glue code required by the particular C/C++ runtime being used
 */
